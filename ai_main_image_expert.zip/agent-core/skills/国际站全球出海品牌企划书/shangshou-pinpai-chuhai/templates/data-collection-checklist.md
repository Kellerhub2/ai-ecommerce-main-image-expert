# 数据采集 · 25 项必查清单 v2.0

> 五看每一看至少 3-5 个真实数据点，全文 ≥ 25 个数据点。
> 每个数据点必须可追溯来源 (web_search/web_fetch URL)。

---

## ① 看行业 · 必采 5 项

| # | 数据项 | 来源建议 | 示例查询 |
|---|--------|---------|---------|
| 1 | 全球市场规模（当年） | Mordor Intelligence / Grand View Research | "{category} global market size 2026" |
| 2 | 未来 5-10 年 CAGR | Statista / Dataintelo | "{category} CAGR 2026 2030 forecast" |
| 3 | 目标区域规模 + 增速 | Region-specific reports | "{category} Middle East Africa market growth" |
| 4 | TOP 5 细分品类清单 | Industry reports + 阿里巴巴行业大盘 | "{category} segments breakdown growth top" |
| 5 | 中国出口占比 | 海关总署 / GACC | "China export {category} share global percentage" |

---

## ② 看趋势 · 必采 4 项

| # | 数据项 | 来源建议 | 示例查询 |
|---|--------|---------|---------|
| 6 | 结构性趋势 1（技术/政策/消费） | 行业白皮书 + 新闻 | "{category} disruption trend 2030 EV digital" |
| 7 | 结构性趋势 2 | Industry insiders | "{industry} regulation change next 5 years" |
| 8 | 结构性趋势 3 | Consumer reports | "{category} consumer behavior shift" |
| 9 | TOP 5 爆款品类预测（2 年翻倍） | 综合多源验证 | "{category} fastest growing products 2026 2028" |

---

## ③ 看海外买家 · 必采 10 项（最关键）

| # | 数据项 | 来源建议 | 示例查询 |
|---|--------|---------|---------|
| 10 | TOP 10 欧洲买家点名 | LinkedIn + 行业目录 | "top {category} distributors Europe France Germany UK" |
| 11 | TOP 10 中东非买家点名 | Automechanika 参展商名录 | "largest {category} importers Saudi UAE Morocco" |
| 12 | TOP 10 美洲买家点名 | 海关公开数据 | "top {category} buyers North America Latin America" |
| 13 | 各家年采购量级 | 公司财报 / Statista | "{company} annual revenue procurement scale" |
| 14 | 各家核心需求（质量/价格/SKU/服务/认证排序） | 行业访谈 + 客户官网 | "{company} sourcing criteria supplier requirements" |
| 15 | 各家本地差异化（如：24h送达 / 视频教学 / 自有品牌） | 公司官网 | "{company} unique value proposition customer service" |
| 16 | 接触方式（邮箱/LinkedIn/展会摊位） | LinkedIn Sales Navigator | "{company} procurement manager contact" |
| 17 | 买家区域需求优先级（雷达图数据） | 综合采集 | 自动整理上述 7 项 |
| 18 | 决策周期长度 | 行业经验 | "{category} B2B sales cycle weeks months" |
| 19 | 付款条件偏好 | 行业经验 | "{category} payment terms LC TT 30days" |

⚠️ **质量底线**：TOP 10 必须点名（不允许"某欧洲分销商"），不够 10 个时至少给 5-7 个真实名字 + 标注"待补充更多"。

---

## ④ 看竞争对手 · 必采 6 项

| # | 数据项 | 来源建议 | 示例查询 |
|---|--------|---------|---------|
| 20 | 国际站 TOP 5 竞品店铺链接 | alibaba.com 类目搜索 | web_fetch "alibaba.com/trade/search?keyword={category}" |
| 21 | 竞品关键数据对比表（SKU/响应/认证/年成交） | 各竞品店铺主页 | web_fetch 每个店铺 |
| 22 | 竞品定位 / 视觉 / SKU 战略 / 服务 4 维度 | 店铺旺铺装修 | 每家店铺人工识别 |
| 23 | 竞品自有品牌情况 | About Us 页面 | "{competitor} brand portfolio" |
| 24 | 行业基准（响应率/年成交均值） | 阿里官方数据 | 阿里营销大数据 |
| 25 | 借鉴 + 超越点（每个竞品 1+1） | 综合分析 | 内部推导 |

⚠️ **质量底线**：5 个竞品必须有 Alibaba.com 真实链接，且能验证存在。

---

## ⑤ 看自己 · 必采（用户输入 + 店铺抓取）

无固定数据条数，但必须覆盖：

| 维度 | 必采字段 |
|------|---------|
| 公司信息 | 名称 / 注册地 / 成立年 / 员工数 / 厂房面积 / 产线数 |
| 国际站资质 | 金品级别 / 响应率 / 响应时长 / 星等 / 评分 |
| 产品现状 | 在线 SKU 数 / TOP 5 主营品类 / 平均客单价 |
| 资质认证 | ISO/CE/FDA/IATF 等 |
| 营业规模 | 年外贸营业额 / 主要出口市场 |
| 痛点 | 老板自述（用 ask_user 获取）|

---

## 📊 数据来源优先级（高 → 低）

1. **阿里巴巴官方数据**（最权威，但需登录）
2. **Statista / Mordor Intelligence / Grand View Research**（付费报告免费摘要）
3. **公司财报 / SEC 文件 / Crunchbase**（针对上市/明星公司）
4. **LinkedIn / Crunchbase**（针对中小买家公司）
5. **行业协会 / 展会名录**（Automechanika / Canton Fair 等）
6. **国别商务参赞处 / 海关数据**
7. **行业白皮书 / 咨询机构博客**（Bain / McKinsey / Deloitte）
8. **Wikipedia**（仅作背景参考）

---

## 🚫 数据采集红线

- ❌ 编造公司名（"某大型欧洲分销商"）
- ❌ 引用 3 年以上过期数据（除非明确标注）
- ❌ 不写来源就引用数字
- ❌ 把竞品官网描述当成自己的洞察
- ❌ 用 ChatGPT 训练知识直接生成"行业数据"（必须 web_search 校验）

---

## ✅ 数据采集完成自检

- [ ] 5 项行业数据是否全部采集？
- [ ] 4 项趋势数据是否带 2030 视角？
- [ ] 10 项买家数据是否含 TOP 10 真实点名？
- [ ] 6 项竞品数据是否含 5 个 Alibaba.com 真实链接？
- [ ] 看自己数据是否覆盖公司/资质/产品/认证/规模/痛点 6 维度？
- [ ] 全文是否 ≥ 25 个带来源的数据点？
