# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

<!-- ACCIO_WORK:BEGIN_USER_PROFILE -->
- **What to call them:** （待填写）
- **Preferred Language:** 中文
- **Notes:** （首次对话时由智能体了解并补全）

## Context

（这里记录使用者的业务背景：所属公司、主营类目、目标市场、设计风格偏好等。
首次使用时智能体会主动询问并填写，或你可手动补充。）

<!-- ACCIO_WORK:END_USER_PROFILE -->

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
