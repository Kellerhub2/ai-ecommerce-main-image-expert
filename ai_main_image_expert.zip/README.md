# AI电商主图专家 — Agent 分发包

把整个文件夹（或其 zip）发给对方，对方在 AW（Accio Work）控制台对 Accio 助手说：
**「按这个包里的 manifest.json 帮我创建并安装这个智能体」**，助手即可自动完成创建。

---

## 这是什么

一个面向跨境电商（Alibaba 国际站 / Amazon / Shopify / TikTok Shop）的
**产品主图设计与 CTR 优化**智能体，自带人格设定、16 个技能、2 个插件依赖与工具白名单。

## 包内文件

```
AI电商主图专家-分发包/
├── manifest.json              # 安装清单（Accio 助手按此自动创建）★入口
├── profile.template.jsonc     # Agent 配置模板（去标识化）
├── README.md                  # 本说明
├── avatar.png                 # 头像
└── agent-core/
    ├── SOUL.md                # 人格/灵魂定义
    ├── IDENTITY.md            # 名称与风格
    ├── USER.md                # 用户画像（空白模板）
    ├── MEMORY.md              # 长期记忆（空白模板）
    ├── diary/                 # 日记目录（空）
    └── skills/                # 16 个技能
        ├── skills.jsonc       # 技能注册表（installPath 已占位化）
        ├── 阿里国际站产品主图与详情页/   # ★核心，config.md 已重置为空白
        ├── 国际站全球出海品牌企划书/
        ├── 多语言商品描述生成器/
        ├── 爆款标题公式引擎/
        └── （另含 12 个市场/营销/竞品分析类技能）
```

## 安装步骤（控制台 Accio 助手自动执行）

1. **创建 Agent**：按 `profile.template.jsonc` 创建，`name=AI电商主图专家`、`vibe=professional`、模型 Claude Opus 4.8。`id / accountId / createdAt / defaultProject.dir` 由控制台自动生成。
2. **放置身份文件**：将 `agent-core/` 下的 SOUL/IDENTITY/USER/MEMORY 与 `avatar.png` 拷入新 Agent 对应目录。
3. **安装技能**：把 `agent-core/skills/` 整个拷入新 Agent 的技能目录，并将 `skills.jsonc` 中所有 `installPath` 里的占位符 `<AGENT_SKILLS_DIR>` 替换为新 Agent 的 `agent-core/skills` 绝对路径。
4. **启用插件**：在控制台为该 Agent 启用 `alibaba-com-seller-assistant`（必需）与 `figma-assistant`（可选）。若控制台无这些插件，相关能力不可用，但不影响主图核心技能。
5. **应用工具白名单**：按 `toolInclude` 勾选内置工具。

## 安装后首次使用

- 打开技能 **「阿里国际站产品主图与详情页」** 的 `config.md`，填写公司名、类目、品牌色等信息，并把顶部 `CONFIGURED: false` 改成 `true`。
- 然后对智能体说「配置好了」即可开始制作主图 / 详情页。

## 隐私说明

本包已**去标识化**，可安全分享给任何人：
- `config.md`、`USER.md`、`MEMORY.md` 均为空白模板，无原作者公司/个人数据。
- `skills.jsonc` 中的绝对路径已替换为 `<AGENT_SKILLS_DIR>` 占位符。
- 不含原 Agent 的 `id`、`accountId`、`sessions`、`runtime` 等账号绑定数据。
