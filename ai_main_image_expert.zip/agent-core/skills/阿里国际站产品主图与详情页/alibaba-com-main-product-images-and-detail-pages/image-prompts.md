# AI 生图提示词库 — 阿里国际站主图 & 详情页

使用说明：从对应类目选取模板，将 `[占位符]` 替换为实际产品信息后，传入 `image_generate` 工具。
如用户已提供产品图片素材，优先使用 `image_edit` 工具在原图基础上调整。

> **配置驱动**：先读取 `config.md`。其中的「类目代码」决定使用下方哪个类目段的配色/场景/材质风格；
> 「公司名 / 工厂数据 / 认证 / MOQ / 交期 / 品牌色」等字段用于替换提示词中的 `[占位符]`。
> config.md 未填的字段才向用户临时询问。

---

## 通用主图提示词模板

### 图1 — 首图（产品+数字化实力+卖点）

```
Professional B2B product hero image for Alibaba.com listing.[Product Name].
[1] Layout Structure (Must Be Strictly Followed):
A prominent, industry-specific selling point (e.g., “FREE DESIGN”) has been added at the top of the left sidebar. Left 1/3 of the sidebar: 4–5 neat, rounded rectangles arranged vertically. Inside, use high-contrast white bold text: “OEM/ODM,” “Samples: [3–7 days],” “Batch: [10–25 days],” and “Minimum Order Quantity: [30–50] pieces.” (Adjust timeframes and quantities according to industry standards.)
Bottom Footer: 4–6 authoritative industry certification logos (e.g., [Certificate 1, Certificate 2, Certificate 3...]), with refined icons arranged horizontally and neatly aligned with the bottom edge.
Right-side/Centered Display: Present [Product Name] in a 1:1 aspect ratio. Keep the main product image unchanged and use a hyper-realistic effect. Ensure the product is positioned in the right 2/3 of the frame with the entire product clearly visible.
[3] - Resolution: 4K, Image ratio: 1:1, 1200x1200px.
No watermarks, no contact information.
```

### 图2 — 产品细节卖点A

```
Product detail feature image for B2B e-commerce.
Main subject: Close-up detail shot of [产品名称], showing [材质/工艺/结构特点].
Layout: Split composition — left side product macro detail, right side feature callout icons with text areas.
Callout arrows pointing to key features: [卖点1], [卖点2], [卖点3].
Background: Clean white or very light neutral gray.
Style: Technical product photography with infographic elements, professional and clean.
Lighting: Even, shadow-free studio lighting to show material texture clearly.
Image ratio: 1:1, 1200x1200px.
```

### 图3 — 产品细节卖点B / 使用场景

```
Product application scene image for B2B catalog.
Subject: [产品名称] in realistic use environment — [使用场景描述].
Style: Lifestyle commercial photography, showing product in professional context.
Atmosphere: [类目对应场景氛围].
Include subtle brand presence.
Multiple product variants or color options displayed if applicable.
Background: [场景背景描述], not overly busy.
Professional photography quality, well-composed, natural lighting.
Image ratio: 1:1, 1200x1200px.
```

### 图4 — 公司实力A

```
Company strength showcase banner for Alibaba.com.
Layout: Grid of 4-6 data cards / stat blocks showing company credentials.
Visual elements: Factory exterior photo (modern, large-scale) as background (30% opacity overlay).
Data cards content areas for: [建厂年份] Years Experience / [工厂面积]㎡ Factory / [员工数] Employees / [产能] Annual Output / [出口国] Countries Exported / [认证数] Certifications.
Each card has icon + number + label.
Color scheme: Deep navy blue or dark green with white text — professional, trust-building.
Style: Corporate infographic, B2B marketing collateral.
Image ratio: 1:1, 1200x1200px.
```

### 图5 — 公司实力B / 服务能力

```
Services and certifications showcase image for B2B supplier profile.
Top section: Row of certification badge icons — [认证列表: ISO/CE/FDA/ROHS etc.].
Middle section: Service icons grid — OEM/ODM Custom, Fast Sample, Custom Packaging, Global Shipping, After-sales Support.
Bottom section: Partner brand logos strip or quality inspection process flow.
Color scheme: Professional blue-white or dark charcoal-gold, conveying reliability.
Style: Clean corporate design, trust signals, B2B focused.
Image ratio: 1:1, 1200x1200px.
```

### 图6 — CTA 行动号召

```
Call-to-action promotional banner for Alibaba.com product listing.
Layout: Bold CTA-focused design.
Headline area: "Get Free Sample" or "Contact Us for Best Price" — large, bold typography.
Product image: [产品名称] thumbnail, bottom-right corner.
Benefit icons (3 items): Free Sample Available / [交期] Fast Delivery / Custom Logo Service.
Urgency element: Limited time offer badge or "Send Inquiry Now" button graphic.
Color: High contrast — deep blue/orange or red/white, energetic and action-driving.
Style: Promotional e-commerce banner, conversion-optimized.
Image ratio: 1:1, 1200x1200px.
```

---

## 按类目定制提示词补充

### ELEC — 3C 电子

**色调**：`Tech blue, silver metallic, dark background with light product emphasis`
**场景**：`Modern office desk setup, smart home environment, tech-savvy lifestyle`
**材质展示**：`Premium aluminum alloy texture, precision engineering, circuit board detail`
**图1补充**：`Clean room or electronics assembly line background, technician in ESD-safe uniform`

```
[图2/3 细节补充]
Electronic product detail photography.
Show: Precision connectors, material finish quality, technical specifications callouts.
Background: Dark charcoal or gradient tech background.
LED accent lighting to highlight product contours.
Technical spec tags with clean minimal typography.
```

---

### HOME — 家居家具

**色调**：`Warm neutral tones, Scandinavian white, earth tones, lifestyle warmth`
**场景**：`Modern living room, bedroom, kitchen, minimalist interior design`
**材质展示**：`Wood grain texture, fabric weave, metal finish, stone surface`
**图1补充**：`Furniture workshop or upholstery production line, craftsman at work`

```
[图2/3 细节补充]
Home furniture/decor detail photography.
Show: Material texture closeup, joinery quality, surface finish detail.
Lifestyle background: Styled interior room, soft natural window light.
Warm, inviting atmosphere. Scandinavian or contemporary interior styling.
Props: Complementary decor items to create aspirational home scene.
```

---

### APPAREL — 服装服饰

**色调**：`Fashion-forward, clean white studio or lifestyle editorial`
**场景**：`Fashion studio, outdoor lifestyle, commercial retail environment`
**材质展示**：`Fabric weave closeup, stitching quality, zipper/button detail`
**图1补充**：`Garment factory sewing line, quality control inspector examining fabric`

```
[图2/3 细节补充]
Apparel/textile detail photography.
Show: Fabric texture macro, stitching precision, hardware quality (buttons, zippers).
Flat lay or mannequin display for full garment.
Fabric drape quality on body or hanger.
Color accuracy critical — neutral background to show true color.
Size chart graphic overlay if applicable.
```

---

### BEAUTY — 美妆个护

**色调**：`Soft pink, gold, white, clean pharmaceutical-style or luxury cosmetic`
**场景**：`Bathroom vanity, beauty studio, spa environment, skincare routine`
**材质展示**：`Product texture (cream, liquid, powder), packaging premium finish`
**图1补充**：`Cosmetic manufacturing clean room, lab technician in white coat`

```
[图2/3 细节补充]
Beauty product photography.
Show: Product texture/consistency (if applicable — swatch, application), packaging detail.
Ingredients visual if natural/organic: botanical elements, raw ingredients arranged artfully.
Soft diffused lighting, feminine and premium atmosphere.
Before/after indication area (tasteful, professional).
Certification badges: Cruelty-free, Organic, Dermatologist-tested.
```

---

### OUTDOOR — 户外运动

**色追**：`Adventure green, earth tones, action energy colors (orange, red)`
**场景**：`Mountain, camping site, trail, gym, sports field`
**材质展示**：`Weatherproof coating, heavy-duty stitching, technical fabric`
**图1补充**：`Outdoor gear testing facility or production line, quality stress-testing`

```
[图2/3 细节补充]
Outdoor/sporting goods product photography.
Show: Durability features — reinforced stitching, waterproof coating, load-bearing hardware.
Action context: Product in use in outdoor/adventure environment.
Rugged, dynamic composition. Natural light preferred.
Technical callouts: Waterproof rating, weight capacity, material specs.
```

---

### INDUSTRIAL — 工业机械

**色调**：`Industrial steel gray, safety yellow, professional navy blue`
**场景**：`Factory floor, workshop, construction site, industrial application`
**材质展示**：`Metal precision, welding quality, mechanical components`
**图1补充**：`Heavy machinery production workshop, engineer in hard hat inspecting equipment`

```
[图2/3 细节补充]
Industrial machinery/component product photography.
Show: Precision engineering detail — machining marks, tolerance specifications, material grade.
Technical cross-section or exploded view diagram style.
Strong directional lighting to show surface precision and finish.
Safety certification marks prominently displayed.
Scale reference (ruler, hand) to show actual size.
Technical specification overlay with dimension callouts.
```

---

### AUTO — 汽车配件

**色调**：`Automotive silver, carbon fiber texture, premium black`
**场景**：`Car interior/exterior install context, auto shop, racing circuit`
**材质展示**：`Metal plating, rubber seal, electronic connector detail`
**图1补充**：`Auto parts manufacturing line, quality inspector with calipers`

```
[图2/3 细节补充]
Automotive parts photography.
Show: Precision fit and finish — OEM compatibility features, material quality.
Installation context: Part shown on/near vehicle for scale and fitment reference.
Surface treatment detail: Chrome plating, powder coating, anodizing.
Compatible vehicle list visual element.
```

---

### FOOD — 食品农产品

**色调**：`Fresh natural green, warm harvest tones, clean white food-safe`
**场景**：`Farm field, kitchen, food service environment, retail packaging`
**材质展示**：`Product freshness, texture, natural origin`
**图1补充**：`Food processing facility, quality inspector in food-safe uniform and gloves`

```
[图2/3 细节补充]
Food product photography.
Show: Product freshness and quality — texture, color vibrancy, natural appearance.
Origin story visual: Farm/source environment as background.
Nutrition/ingredient callout area.
Packaging shot showing labeling, certifications (HACCP, Organic, Halal etc.).
Appetizing, clean, and food-safe visual presentation.
```

---

### BABY — 母婴玩具

**色调**：`Soft pastel, gentle cream, playful primary colors`
**场景**：`Nursery, playroom, outdoor play area, parent-child interaction`
**材质展示**：`Soft fabric, rounded edges, non-toxic material emphasis`
**图1补充**：`Toy/baby product safety testing facility, quality inspector with products`

```
[图2/3 细节补充]
Baby/children product photography.
Show: Safety features — rounded edges, non-toxic materials, certifications (EN71, ASTM, CPSC).
Child in use (without showing child's face for privacy if needed) or parent interaction.
Soft, warm, nurturing atmosphere.
Safety certification badges prominently displayed.
Age-appropriate indicators.
```

---

### PET — 宠物用品

**色调**：`Playful, warm, pet-friendly natural tones`
**场景**：`Home pet environment, outdoor with pet, veterinary clean`
**材质展示**：`Pet-safe materials, durability for chewing/scratching`
**图1补充**：`Pet product manufacturing with quality control, material safety testing`

```
[图2/3 细节补充]
Pet product photography.
Show: Product with adorable pet if possible, or styled pet environment.
Material safety callouts: BPA-free, food-grade, non-toxic.
Size/weight capacity indicators.
Durability features for active pets.
Warm, lifestyle-oriented atmosphere.
```

---

### HEALTH — 医疗健康

**色调**：`Clinical white, medical blue, reassuring professional tones`
**场景**：`Medical facility, home health use, professional healthcare setting`
**材质展示**：`Medical-grade material, precision engineering, hygiene design`
**图1补充**：`Medical device manufacturing clean room, technician in sterile uniform`

```
[图2/3 细节补充]
Medical/health product photography.
Show: Precision and reliability — measurement accuracy, material quality, ergonomic design.
Professional medical context without being overly clinical.
Certification badges: CE, FDA, ISO 13485 prominently placed.
Easy-to-use feature callouts for home health users.
Trust-building, clean, professional aesthetic.
```

---

### GIFT — 礼品定制

**色调**：`Premium gold, festive seasonal tones, luxury packaging aesthetic`
**场景**：`Gift presentation setup, corporate gifting context, retail display`
**材质展示**：`Packaging premium, customization options, logo placement`
**图1补充**：`Gift product customization workshop, personalization process`

```
[图2/3 细节补充]
Promotional gift/custom product photography.
Show: Customization options — logo placement, color variations, packaging choices.
Premium gifting presentation: ribbon, gift box, elegant arrangement.
Corporate context: Professional desk, business meeting setting.
MOQ and customization lead time callout area.
```

---

## 详情页模块生图提示词

### 模块1 — 公司实力Banner（详情页首图）

```
Company profile banner image for Alibaba.com product detail page, 1200px wide.
Full-width horizontal layout.
Left 40%: Company/factory hero image — modern facility exterior or aerial view.
Right 60%: Company credentials grid:
  - Founded year badge
  - Factory size in ㎡
  - Countries exported to
  - Key certifications row
  - Employee count
Headline: "[公司名] — Your Trusted [行业] Manufacturer Since [年份]"
Color: Deep professional blue or dark charcoal with white/gold accents.
Style: Corporate B2B marketing banner, trust-inspiring.
```

### 模块2 — 产品参数表

```
Product specification table graphic for e-commerce detail page, 1200px wide.
Clean data table design with alternating row colors (white/very light gray).
Column headers: Specification | Details
Rows listing: [从产品信息中提取的规格参数]
Left side: Product isometric or front view image.
Header: "Product Specifications" in bold.
Footer: Note area for customization options.
Style: Technical documentation meets modern e-commerce design.
Professional, easy-to-read typography.
```

### 模块3 — 细节展示

```
Product detail zoom section for e-commerce page, 1200px wide.
Grid layout: 3 or 4 detail image panels.
Each panel: Product macro photograph + callout label.
Panel subjects: [细节卖点1] / [细节卖点2] / [细节卖点3] / [细节卖点4]
Each panel has: Detail image (top 70%) + label text (bottom 30%).
Unified background: Very light gray or white.
Style: Technical product catalog, premium quality feel.
```

### 模块4 — 核心卖点

```
Key selling points feature section for B2B product listing, 1200px wide.
Layout: 3 or 4 feature cards in horizontal row.
Each card: Icon (line art style) + Bold feature title + 2-line description.
Features: [卖点1] / [卖点2] / [卖点3] / [卖点4]
Card style: Clean white cards with subtle shadow, accent color top border.
Background: Light gray or gradient.
Typography: Professional, readable, B2B appropriate.
Accent color: [类目对应主色调]
```

### 模块5 — 公司详细实力

```
Detailed company capability section for supplier profile page, 1200px wide.
Multi-section layout:
Section A: Factory photos grid (4 images) — production line, equipment, warehouse, QC lab.
Section B: R&D and technology capability highlights.
Section C: Export history world map with highlighted countries.
Section D: Quality control process flow (4-step infographic).
Style: Professional corporate brochure style, information-dense but organized.
Color: Consistent with overall listing color scheme.
```

### 模块6 — FAQ

```
FAQ section graphic for product listing page, 1200px wide.
Accordion/list style design.
Q&A pairs — 5 to 8 questions:
[从产品信息生成的常见问题]
Layout: Question in bold + answer in regular weight below.
Each Q separated by subtle divider line.
Left accent: Question number or Q icon in brand color.
Style: Clean, professional, easy to scan.
Bottom CTA: "Have More Questions? Send Us an Inquiry" button graphic.
```
