---
name: trending-title-engine
description: Trending title formula engine for cross-border e-commerce. Generates high-CTR product titles based on industry hot words, search trends, and platform algorithms. Supports A/B test version output. Use when the user needs to create optimized product titles for Alibaba, Amazon, or other e-commerce platforms with data-driven keyword strategies.
---

# 爆款标题公式引擎

## 核心功能

基于行业热词、搜索趋势和平台算法，自动生成高点击率的商品标题，支持 A/B 测试版本输出。

## 标题公式库

### 公式 1: 功能属性型
```
[修饰词] + [核心关键词] + [材质/工艺] + [功能特性] + [应用场景]
示例: Professional Waterproof Stainless Steel Smart Watch GPS Tracker for Outdoor Sports
```

### 公式 2: 场景需求型
```
[场景词] + [核心关键词] + [差异化卖点] + [规格/型号]
示例: Home Office Ergonomic Mesh Chair Lumbar Support Adjustable Height 360 Swivel
```

### 公式 3: 品质认证型
```
[品质词] + [认证/标准] + [核心关键词] + [核心卖点] + [目标人群]
示例: Premium FDA Approved Silicone Baby Feeding Set BPA Free for Toddlers 6-12 Months
```

### 公式 4: 热点趋势型
```
[趋势词/年份] + [核心关键词] + [创新点] + [差异化特征]
示例: 2026 New Arrival Solar Powered Outdoor Security Camera Wireless AI Motion Detection
```

### 公式 5: B2B 批发型 (Alibaba)
```
[交易词] + [定制词] + [核心关键词] + [规格] + [认证]
示例: Wholesale Custom Logo Eco-friendly Cotton Canvas Tote Bag BSCI Certified Factory
```

## 工作流程

### 1. 信息采集

```
请提供以下信息:
- 产品名称/类别
- 目标平台 (Alibaba/Amazon/独立站)
- 目标市场 (美国/欧洲/全球)
- 核心卖点 (2-3 个)
- 竞品标题参考 (如有)
- 目标关键词 (如有)
```

### 2. 热词研究

1. **平台热搜词挖掘**
   - 搜索 "[product] trending keywords [platform] 2026"
   - 搜索 "[product] best seller title [platform]"
   - 搜索 "[product category] hot search terms"

2. **竞品标题分析**
   - 搜索平台 Top 20 同类产品标题
   - 提取高频词汇和结构模式
   - 识别差异化用词机会

3. **搜索趋势验证**
   - 搜索 "google trends [product keyword]"
   - 验证关键词搜索量趋势
   - 识别季节性和上升趋势词

### 3. 标题生成规则

**Alibaba 国际站:**
- 字符数: 60-128 字符
- 核心关键词在前 60 字符
- 包含: 修饰词 + 核心词 + 属性 + 场景
- 避免: 堆砌、特殊符号、夸大词

**Amazon:**
- 字符数: 150-200 字符
- 品牌名在最前
- 包含: 品牌 + 核心词 + 关键特征 + 规格 + 颜色/数量
- 避免: 全大写、促销语、主观评价

**独立站:**
- 字符数: 50-70 字符 (SEO Title)
- 包含主要关键词
- 自然可读，吸引点击
- 考虑 Google SERP 展示效果

### 4. A/B 测试版本输出

为每个产品生成 3-5 个标题变体:

```
## A/B 测试标题方案

### 方案 A - 关键词优先型
标题: [title A]
字符数: [X]
策略: 核心关键词前置，最大化搜索匹配
预期效果: 搜索排名提升，曝光量增加

### 方案 B - 卖点突出型
标题: [title B]
字符数: [X]
策略: 差异化卖点前置，突出产品独特性
预期效果: 点击率提升，精准用户转化

### 方案 C - 场景驱动型
标题: [title C]
字符数: [X]
策略: 使用场景词引发需求共鸣
预期效果: 唤醒需求，提升非搜索流量转化

### 方案 D - 趋势借力型
标题: [title D]
字符数: [X]
策略: 结合当前热点趋势词
预期效果: 借势热点，提升短期流量

### 方案 E - 平衡型 (推荐)
标题: [title E]
字符数: [X]
策略: 平衡搜索优化和点击吸引力
预期效果: 综合表现最佳
```

## 输出模板

```
# 爆款标题生成报告

## 产品信息
- 产品: [产品名称]
- 平台: [目标平台]
- 市场: [目标市场]
- 类目: [所属类目]

## 热词分析
### 核心关键词 (必选)
- [keyword 1] - 搜索热度: 高
- [keyword 2] - 搜索热度: 高

### 趋势热词 (推荐)
- [trend word 1] - 上升趋势
- [trend word 2] - 上升趋势

### 长尾词 (可选)
- [long-tail 1] - 竞争度低
- [long-tail 2] - 竞争度低

## 标题方案 (A/B Test)

### 推荐方案 (Score: X/100)
**[推荐标题]**
- 字符数: [X]
- 公式: [使用的公式]
- 核心关键词覆盖: [X] 个
- 预期 CTR 提升: [X]%

### 备选方案 1
[标题]
- 策略: [X]

### 备选方案 2
[标题]
- 策略: [X]

### 备选方案 3
[标题]
- 策略: [X]

## 标题优化建议
1. [建议 1]
2. [建议 2]
3. [建议 3]

## 测试建议
- 测试周期: 7-14 天
- 核心指标: CTR、转化率、搜索排名变化
- 流量分配: 各方案均分流量
```

## 注意事项

1. **避免堆砌**: 同一关键词最多出现 2 次
2. **可读性**: 标题必须通顺可读，非简单词汇罗列
3. **合规性**: 不使用 "Best", "No.1", "#1" 等夸大词
4. **时效性**: 趋势词需验证当前有效性
5. **差异化**: 与竞品标题形成差异，避免同质化
6. **数据驱动**: 基于搜索数据而非主观判断选词
