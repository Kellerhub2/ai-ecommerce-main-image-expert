---
name: multilingual-product-description
description: Multilingual product description generator for cross-border e-commerce. Input Chinese product info to auto-generate English, Spanish, French, German versions of titles, descriptions, and keywords. Adapts to platform requirements (Alibaba, Amazon, independent sites) for character limits and formatting. Use when the user needs to translate or generate product listings in multiple languages for international platforms.
---

# 多语言商品描述生成器

## 核心功能

输入中文商品信息，自动生成英语、西班牙语、法语、德语等多语言版本的标题、描述、关键词，适配不同平台（Alibaba、Amazon、独立站）的字数和格式要求。

## 支持的语言

- 英语 (English)
- 西班牙语 (Espanol)
- 法语 (Francais)
- 德语 (Deutsch)
- 葡萄牙语 (Portugues)
- 意大利语 (Italiano)
- 俄语 (Русский)
- 阿拉伯语 (العربية)
- 日语 (日本語)

## 平台适配规则

### Alibaba 国际站
- **标题**: 60-128 字符，核心关键词前置
- **描述**: 1000-5000 字，HTML 格式，图文结合
- **关键词**: 3 个，不可重复
- **风格**: B2B 专业商务，强调 MOQ、OEM/ODM、认证

### Amazon
- **标题**: 150-200 字符（不同站点有差异）
- **Bullet Points**: 5 条，每条 200 字符以内
- **描述**: 2000 字符以内
- **关键词**: 后台搜索词 250 字符
- **风格**: 突出卖点、用途、场景，面向终端消费者

### 独立站 (Shopify/WooCommerce)
- **标题**: 60-70 字符（SEO 友好）
- **Meta Description**: 150-160 字符
- **描述**: 无字数限制，SEO 优化，结构化内容
- **关键词**: 融入自然语句
- **风格**: 品牌调性一致，故事化描述

## 工作流程

### 1. 信息采集

当用户提供中文商品信息时，提取以下核心要素：

```
- 产品名称
- 产品类别
- 核心卖点 (3-5 个)
- 材质/规格/参数
- 适用场景/人群
- 价格区间
- MOQ (如适用)
- 认证/资质
- 品牌信息
```

### 2. 多语言生成策略

1. **语义翻译而非直译**
   - 理解产品核心价值主张
   - 根据目标语言的表达习惯重新组织语言
   - 考虑文化差异和消费习惯

2. **关键词本地化**
   - 搜索目标语言市场的热门搜索词
   - 使用 WebSearch 搜索 "[product] keywords [language/country]"
   - 融入本地化表达和搜索习惯

3. **平台规则适配**
   - 根据目标平台调整字数、格式
   - 遵循各平台的违禁词规则
   - 适配不同平台的 SEO 算法

### 3. 生成内容结构

对每个语言版本，生成以下内容：

```
## [语言] - [平台] 版本

### 标题
[生成的标题] (字符数: X)

### 关键词
1. [关键词 1]
2. [关键词 2]
3. [关键词 3]

### 短描述 / Bullet Points
- [卖点 1]
- [卖点 2]
- [卖点 3]
- [卖点 4]
- [卖点 5]

### 长描述
[完整产品描述]

### SEO Meta (独立站适用)
- Meta Title: [X]
- Meta Description: [X]
```

## 输出模板

```
# 多语言商品描述 - [产品名称]

## 原始中文信息
[用户输入的中文产品信息]

---

## English (英语)

### Alibaba Version
**Title** (XX chars): [title]
**Keywords**: [kw1], [kw2], [kw3]
**Short Description**: [description]
**Product Detail** (HTML):
[html content]

### Amazon Version
**Title** (XX chars): [title]
**Bullet Points**:
- [point 1]
- [point 2]
- [point 3]
- [point 4]
- [point 5]
**Backend Keywords**: [keywords]
**Description**: [description]

### Independent Site Version
**Meta Title** (XX chars): [title]
**Meta Description** (XX chars): [meta desc]
**Product Description**: [description]

---

## Espanol (西班牙语)
[同上结构]

---

## Francais (法语)
[同上结构]

---

## Deutsch (德语)
[同上结构]

---

## 质量检查
- [ ] 各语言版本字数符合平台要求
- [ ] 关键词已本地化（非直译）
- [ ] 无语法错误
- [ ] 符合各平台违禁词规则
- [ ] 文化适配无歧义
```

## 注意事项

1. **文化适配**: 避免直译导致的文化冲突或歧义
2. **关键词优先**: 标题前部放置搜索量最大的关键词
3. **平台合规**: 不使用夸大、虚假、侵权词汇
4. **一致性**: 同一产品各语言版本的核心卖点保持一致
5. **本地化度量单位**: 根据目标市场转换单位（英寸/厘米、磅/千克等）
6. **货币本地化**: 根据目标市场显示对应货币
