# 经营定位"五看三定"全案 · 深度模板 v2.0

> **本模板是上手品牌出海 SKILL 的核心差异化资产（v2.0 精炼版）。**
> 严禁空泛套话。每一看必须遵循 **数据 → 洞察 → 行动** 三段式，并产出可落地的方案。

---

## ⭕ 总体质量要求（强制性）

| 维度 | 最低要求 |
|------|---------|
| 真实数据点 | 全文 ≥ 25 个（每一看 ≥ 3 个，需 web_search 佐证带来源） |
| 行动框 | 每一看结尾必须给【M1立办/M2深化/M3收割】三层动作 |
| 行动框 4 要素 | 时间窗口 + 负责人 + 预算 + 预期效果（缺一不可） |
| 禁用词 | "市场广阔/前景巨大/未来可期/百花齐放" 等空话 |
| 必含元素 | 至少 2 个 Chart.js 图表（行业曲线 + 竞争象限/雷达） |

---

## 🎯 五看三定 · 章节框架

### ① 看行业 · 空间/增速/具体机会品类

**必须回答 3 个问题：**
1. **空间**：全球总规模？目标区域规模？复合年增长率 CAGR？
2. **增速**：哪些子赛道增速 > 行业平均 2 倍？
3. **具体机会品类**：列出 TOP 5 最具潜力的细分品类 + 数据支撑

**HTML 模板结构：**
```html
<div class="sec-sub">① 看行业 · {{INDUSTRY_NAME}}（{{REGION}}市场）</div>

<!-- KPI 卡片：4 项空间/增速核心数据 -->
<div class="grid-4">
  <div class="kpi"><div class="kpi-label">全球规模(2026)</div><div class="kpi-num">${{GLOBAL_SIZE}}</div></div>
  <div class="kpi"><div class="kpi-label">目标区域CAGR</div><div class="kpi-num green">{{CAGR}}%</div></div>
  <div class="kpi"><div class="kpi-label">中国出口占比</div><div class="kpi-num">{{CHINA_SHARE}}%</div></div>
  <div class="kpi"><div class="kpi-label">高增速子赛道</div><div class="kpi-num gold">{{SUB_CAGR}}%</div></div>
</div>

<!-- 增长曲线 Chart -->
<div class="chart-wrap"><canvas id="industryChart" height="100"></canvas></div>

<!-- TOP 5 机会品类表 -->
<table class="versus-table">
  <tr><th>排名</th><th>品类</th><th>2026规模</th><th>CAGR</th><th>毛利率</th><th>切入门槛</th><th>推荐度</th></tr>
  <!-- 5 行品类数据 -->
</table>

<!-- 行动框 -->
<div class="action-box">
  <div class="title">🎯 行业行动建议</div>
  <ul>
    <li><strong>【M1立办】</strong>{{动作}} | 负责人 | 预算 | 预期效果</li>
    <li><strong>【M2深化】</strong>...</li>
    <li><strong>【M3收割】</strong>...</li>
  </ul>
</div>
```

---

### ② 看趋势 · 未来机会爆款 + 行业机会空间

**必须回答 3 个问题：**
1. **结构性趋势**：未来 3-5 年改变行业格局的 3 大力量（技术/政策/消费）
2. **爆款品类**：哪 3-5 款单品未来 2 年增速翻倍？
3. **空间窗口**：抢占窗口期还剩多久？

**HTML 模板结构：**
```html
<div class="sec-sub">② 看趋势 · 未来 3-5 年爆款机会</div>

<!-- 三大趋势卡片 -->
<div class="grid-3">
  <div class="card" style="border-top:4px solid var(--blue);">
    <h4>🚀 趋势 ① {{TREND_NAME}}</h4>
    <p><strong>驱动力：</strong>{{DRIVER}}</p>
    <p><strong>受益品类：</strong>{{CATEGORY}}</p>
    <p><strong>窗口期：</strong>{{WINDOW}}</p>
  </div>
  <!-- 趋势 ②③ -->
</div>

<!-- 爆款品类预测表 -->
<table class="versus-table">
  <tr><th>爆款品类</th><th>当前规模</th><th>2027预测</th><th>增速</th><th>关键驱动力</th><th>抢占动作</th></tr>
</table>

<!-- 行动框 -->
<div class="action-box">...</div>
```

---

### ③ 看海外买家 · TOP 10 是谁/需求是什么/他们的差异化点

**必须回答 4 个问题：**
1. **TOP 10 买家具体是谁**：公司名 + 国家 + 主营 + 采购量级
2. **他们的核心需求**：质量/价格/SKU/服务/认证的优先级排序
3. **他们如何服务本地客户**：渠道/品牌/差异化 3 大动作
4. **可对接的接触点**：邮箱/LinkedIn/展会摊位号

**HTML 模板结构：**
```html
<div class="sec-sub">③ 看海外买家 · TOP 10 深度画像</div>

<!-- TOP 10 买家卡片网格 -->
<div class="grid-3">
  <div class="buyer-card">
    <h4>🇫🇷 {{BUYER_NAME}}</h4>
    <div class="meta">📍 {{COUNTRY}} · {{ANNUAL_SCALE}}</div>
    <div class="needs">
      <strong>核心需求：</strong>
      <ul>
        <li>质量：原厂同等或 +/-10%</li>
        <li>SKU：>3000 款覆盖率</li>
        <li>交期：欧洲 ≤ 30 天</li>
      </ul>
    </div>
    <div class="diff">
      <strong>本地差异化：</strong>
      <ul>
        <li>差异化①：{{DIFF_1}}</li>
        <li>差异化②：{{DIFF_2}}</li>
      </ul>
    </div>
    <div class="contact">📧 {{EMAIL}} · 💼 {{LINKEDIN}}</div>
  </div>
  <!-- ×10 张买家卡片 -->
</div>

<!-- 买家需求优先级矩阵 -->
<div class="chart-wrap"><canvas id="buyerMatrix" height="120"></canvas></div>

<!-- 行动框 -->
<div class="action-box">
  <div class="title">🎯 海外买家攻坚行动建议</div>
  <ul>
    <li><strong>【M1立办】</strong>触达 TOP 10 中的"低门槛"3 家（邮件+LinkedIn 双触点）</li>
    <li><strong>【M2深化】</strong>展会面谈（迪拜 Automechanika / 法兰克福 Automechanika）</li>
    <li><strong>【M3收割】</strong>送样 → 试单 → 长期协议</li>
  </ul>
</div>
```

---

### ④ 看竞争对手 · 国际站 TOP 5 + 他们做对了什么 + 借鉴超越点

**必须回答 4 个问题：**
1. **国际站 TOP 5 竞品是谁**：店铺链接 + 年成交 + 主推品类
2. **他们做对了什么**：定位/视觉/SKU/服务 4 大维度逐一拆解
3. **我们的差距在哪**：3 个数据对比
4. **借鉴 + 超越的具体动作**：每个竞品至少 1 个可立刻抄+1 个可超越的点

**HTML 模板结构：**
```html
<div class="sec-sub">④ 看竞争对手 · 国际站 TOP 5 解构</div>

<!-- 竞品对比表（数据对比） -->
<table class="versus-table">
  <tr><th>维度</th><th>本店</th><th>竞品A</th><th>竞品B</th><th>竞品C</th><th>差距</th></tr>
  <tr><td>在线SKU数</td><td>...</td><td>...</td><td>...</td><td>...</td><td>...</td></tr>
  <tr><td>年成交估算</td><td>...</td><td>...</td><td>...</td><td>...</td><td>...</td></tr>
  <tr><td>客户响应率</td><td>...</td><td>...</td><td>...</td><td>...</td><td>...</td></tr>
  <tr><td>主推品类</td><td>...</td><td>...</td><td>...</td><td>...</td><td>...</td></tr>
  <tr><td>认证齐全度</td><td>...</td><td>...</td><td>...</td><td>...</td><td>...</td></tr>
</table>

<!-- 竞品深度解构卡片 -->
<div class="grid-3">
  <div class="competitor-card">
    <h4>🥇 {{COMP_NAME_1}}</h4>
    <div class="link">🔗 {{ALIBABA_URL}}</div>
    <div class="meta">📊 年成交 ${{GMV}} · {{KEY_CATEGORY}}</div>
    <div class="did-right">
      <strong>✅ 做对了什么：</strong>
      <ol>
        <li>定位：{{POSITIONING}}</li>
        <li>视觉：{{VISUAL}}</li>
        <li>SKU：{{SKU_STRATEGY}}</li>
        <li>服务：{{SERVICE}}</li>
      </ol>
    </div>
    <div class="borrow">
      <strong>🔍 我们可借鉴的：</strong>
      <p>{{BORROW_POINT}}</p>
    </div>
    <div class="surpass">
      <strong>⚡ 我们可超越的：</strong>
      <p>{{SURPASS_POINT}}</p>
    </div>
  </div>
  <!-- ×5 张竞品卡片 -->
</div>

<!-- 借鉴动作清单 -->
<div class="action-box">
  <div class="title">🎯 竞品借鉴 + 超越 10 大动作</div>
  <ol>
    <li>{{ACTION_1}} (借鉴自 {{COMP_NAME}})</li>
    <!-- 10 条动作 -->
  </ol>
</div>
```

---

### ⑤ 看自己 · 店铺/商详/流量/品牌定位的具体调整方案

**必须给出 4 大维度的具体调整方案：**

#### 5.1 店铺调整
- 旺铺视觉 11 大模块逐项诊断
- About Us 故事线重写
- 类目导航重构方案

#### 5.2 商详调整
- TOP 30 SKU 主图重拍清单
- 详情页 7 大模块标准化（卖点/参数/适配车型/认证/包装/物流/FAQ）
- 关键词重新布局

#### 5.3 流量调整
- P4P 关键词重选（聚焦 vs 铺撒）
- RFQ 报价策略升级
- 自然流量提升（标题/类目/星等）

#### 5.4 品牌定位调整
- 品牌名 + Slogan 中英双语
- 价值主张三段式：核心 + 定位 + 承诺
- 视觉调性：色彩/字体/版式标准

**HTML 模板结构：**
```html
<div class="sec-sub">⑤ 看自己 · 4 大维度具体调整方案</div>

<!-- 4 个 Tab/Card 平铺 -->
<div class="self-card store">
  <h3>🏪 5.1 店铺调整 · 旺铺视觉 11 模块诊断表</h3>
  <table class="versus-table">
    <tr><th>模块</th><th>现状评分</th><th>问题</th><th>调整方案</th><th>负责人</th><th>工期</th></tr>
    <!-- 11 行 -->
  </table>
</div>

<div class="self-card detail">
  <h3>📦 5.2 商详调整 · TOP 30 SKU 升级清单</h3>
  <table>...</table>
</div>

<div class="self-card traffic">
  <h3>📈 5.3 流量调整 · P4P + RFQ + 自然 三合一</h3>
  ...
</div>

<div class="self-card brand">
  <h3>🎨 5.4 品牌定位调整 · LOGO/Slogan/视觉新案</h3>
  <!-- 含 AI 生成的 4 张视觉草图 -->
  <div class="grid-2">
    <div class="img-frame"><img src="{{AI_HERO}}"></div>
    <div class="img-frame"><img src="{{AI_FACTORY}}"></div>
    <div class="img-frame"><img src="{{AI_LOGO}}"></div>
    <div class="img-frame"><img src="{{AI_PRODUCT}}"></div>
  </div>
</div>
```

---

## 🎯 三定 · 五看后的战略收官

### 定位 · One-line Positioning
- 一句话品牌定位（中英双语）
- 必须包含：目标客户 + 核心场景 + 差异化点

### 定品 · Top 10 SKU 主推矩阵
- 选定 10 款核心 SKU（按"机会×能力"矩阵筛选）
- 每款给出：定价/MOQ/包装/卖点/适配车型

### 定客 · TOP 30 客户开发名单
- 从看海外买家 TOP 10 扩展到 TOP 30
- 分级：A级（已联系/重点跟进） B级（待破冰） C级（长期培育）
- 每个客户给出：触达通道 / 切入话术 / 下一步动作

---

## 📊 强制图表清单（最少 5 张）

1. **行业增长曲线**（看行业 - line chart）
2. **TOP 5 品类机会矩阵**（看行业/趋势 - bar/radar）
3. **海外买家需求优先级雷达**（看买家 - radar）
4. **竞品竞争象限**（看竞品 - scatter bubble）
5. **本店 vs 行业漏斗对比**（看自己 - bar）

---

## ✅ 自检 Checklist（生成报告前必查）

- [ ] 每一看是否都有 ≥ 3 个真实数据点？
- [ ] 看海外买家是否列出了 TOP 10 具体公司名？
- [ ] 看竞品是否给出了 5 个竞品的"做对/借鉴/超越"3 段式？
- [ ] 看自己是否覆盖 店铺/商详/流量/品牌 4 大维度？
- [ ] 是否给出了三定（定位/定品/定客）的具体方案？
- [ ] Chart.js 图表是否 ≥ 5 张？
- [ ] 行动框是否含 时间/负责人/预算/预期效果 4 要素？
- [ ] 全文是否避免了空泛套话？
