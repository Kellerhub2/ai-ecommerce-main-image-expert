// =================================================================
// 上手品牌出海 · Chart.js 代码片段库 v1.0
// 在生成 HTML 时根据章节按需复制对应函数，并替换数据
// =================================================================

// ----- 1. 行业增长曲线图（§2 看行业）-----
function makeIndustryChart() {
  return `
const indCtx=document.getElementById('industryChart');
if(indCtx) new Chart(indCtx.getContext('2d'),{
  type:'line',
  data:{labels:['2025','2026','2027','2028','2029','2030','2032','2034','2036'],
    datasets:[
      {label:'{{核心赛道1}}(CAGR {{X}}%)',data:[{{基期}},{{Y1}},{{Y2}},{{Y3}},{{Y4}},{{Y5}},{{Y7}},{{Y9}},{{Y11}}],borderColor:'#0E9F6E',backgroundColor:'rgba(14,159,110,0.1)',tension:0.3,fill:true},
      {label:'{{邻品类高增长1}}(CAGR {{X}}%)',data:[],borderColor:'#1B4FD8',backgroundColor:'rgba(27,79,216,0.1)',tension:0.3,fill:true},
      {label:'{{邻品类高增长2}}(CAGR {{X}}%)',data:[],borderColor:'#F59E0B',backgroundColor:'rgba(245,158,11,0.1)',tension:0.3,fill:true}
    ]},
  options:{responsive:true,plugins:{title:{display:true,text:'{{COMPANY_NAME_SHORT}}核心赛道增长曲线对比 (亿美元)'},legend:{position:'top'}}}
});`;
}

// ----- 2. 漏斗对比图（§3 现状诊断）-----
function makeFunnelChart() {
  return `
const fctx=document.getElementById('funnelChart').getContext('2d');
new Chart(fctx,{type:'bar',
  data:{labels:['曝光量','点击量','询盘数','有效商机','订单转化'],
    datasets:[
      {label:'{{COMPANY_NAME_SHORT}}现状',data:[100,{{CTR_NOW*10}},{{INQUIRY_NOW}},{{LEAD_NOW}},{{ORDER_NOW}}],backgroundColor:'#DC2626'},
      {label:'行业Top1标杆',data:[100,{{CTR_TOP}},{{INQUIRY_TOP}},{{LEAD_TOP}},{{ORDER_TOP}}],backgroundColor:'#0E9F6E'}
    ]},
  options:{indexAxis:'y',plugins:{legend:{position:'top'}},scales:{x:{title:{display:true,text:'相对指数 (曝光=100)'}}}}});`;
}

// ----- 3. 竞争象限矩阵（§2 看竞争）-----
function makeCompeteMatrix() {
  return `
const cmCtx=document.getElementById('competeMatrix');
if(cmCtx) new Chart(cmCtx.getContext('2d'),{
  type:'scatter',
  data:{datasets:[
    {label:'{{国际龙头1}}',data:[{x:8.5,y:9,r:18}],backgroundColor:'rgba(59,130,246,0.7)'},
    {label:'{{国际龙头2}}',data:[{x:8,y:8.5,r:22}],backgroundColor:'rgba(99,102,241,0.7)'},
    {label:'{{国际龙头3}}',data:[{x:7.5,y:8,r:16}],backgroundColor:'rgba(139,92,246,0.7)'},
    {label:'{{COMPANY_NAME_SHORT}}(现状)',data:[{x:{{NOW_X}},y:{{NOW_Y}},r:25}],backgroundColor:'rgba(220,38,38,0.7)'},
    {label:'{{COMPANY_NAME_SHORT}}(2026目标)',data:[{x:{{TARGET_X}},y:{{TARGET_Y}},r:25}],backgroundColor:'rgba(252,211,77,0.9)'},
    {label:'国内同行',data:[{x:3.5,y:5,r:14}],backgroundColor:'rgba(156,163,175,0.7)'},
    {label:'东南亚低价厂',data:[{x:2,y:4,r:12}],backgroundColor:'rgba(156,163,175,0.5)'}
  ]},
  options:{responsive:true,plugins:{title:{display:true,text:'全球 {{INDUSTRY}} 竞争象限 (品牌力 × 产能/技术)'},legend:{position:'right'},tooltip:{callbacks:{label:c=>'品牌力'+c.raw.x+', 产能'+c.raw.y}}},
  scales:{x:{title:{display:true,text:'品牌力 (1低 → 10高)'},min:0,max:10},y:{title:{display:true,text:'产能/技术 (1低 → 10高)'},min:0,max:10}}}
});`;
}

// ----- 4. 机会优先级 ROI 图（§2 看机会）-----
function makeOpportunityChart() {
  return `
const oppCtx=document.getElementById('opportunityChart');
if(oppCtx) new Chart(oppCtx.getContext('2d'),{
  type:'bar',
  data:{labels:['{{机会1}}','{{机会2}}','{{机会3}}','{{机会4}}','{{机会5}}','{{机会6}}'],
    datasets:[
      {label:'投入(万元)',data:[{{IN1}},{{IN2}},{{IN3}},{{IN4}},{{IN5}},{{IN6}}],backgroundColor:'#1B4FD8',yAxisID:'y'},
      {label:'12个月内预期回报(万元)',data:[{{OUT1}},{{OUT2}},{{OUT3}},{{OUT4}},{{OUT5}},{{OUT6}}],backgroundColor:'#0E9F6E',yAxisID:'y1'}
    ]},
  options:{responsive:true,plugins:{title:{display:true,text:'五大机会投入产出对比 (ROI排序)'},legend:{position:'top'}},
  scales:{y:{type:'linear',position:'left',title:{display:true,text:'投入 (万元)'}},y1:{type:'linear',position:'right',title:{display:true,text:'回报 (万元)'},grid:{drawOnChartArea:false}}}}
});`;
}

// ----- 5. SWOT 雷达图（§2 看自己）-----
function makeRadarChart() {
  return `
const rctx=document.getElementById('radarChart').getContext('2d');
new Chart(rctx,{type:'radar',
  data:{labels:['生产规模','研发创新','品牌知名度','ESG合规','大B客户','视觉表达','成品化能力','转化效率'],
    datasets:[
      {label:'{{COMPANY_NAME_SHORT}}现状',data:[{{X1}},{{X2}},{{X3}},{{X4}},{{X5}},{{X6}},{{X7}},{{X8}}],backgroundColor:'rgba(220,38,38,0.2)',borderColor:'#DC2626'},
      {label:'12月目标',data:[{{Y1}},{{Y2}},{{Y3}},{{Y4}},{{Y5}},{{Y6}},{{Y7}},{{Y8}}],backgroundColor:'rgba(14,159,110,0.2)',borderColor:'#0E9F6E'},
      {label:'国际龙头基准',data:[{{Z1}},{{Z2}},{{Z3}},{{Z4}},{{Z5}},{{Z6}},{{Z7}},{{Z8}}],backgroundColor:'rgba(27,79,216,0.2)',borderColor:'#1B4FD8'}
    ]},
  options:{scales:{r:{min:0,max:10}}}});`;
}

// ----- 6. 12个月增长曲线（§8 路线图）-----
function makeGrowthChart() {
  return `
const gctx=document.getElementById('growthChart').getContext('2d');
new Chart(gctx,{type:'line',
  data:{labels:['M0','M1','M2','M3','M4','M5','M6','M7','M8','M9','M10','M11','M12'],datasets:[
    {label:'询盘量(基线100)',data:[100,105,115,130,145,160,180,200,220,245,270,295,320],borderColor:'#1B4FD8',backgroundColor:'rgba(27,79,216,0.1)',tension:0.3,fill:true},
    {label:'转化率(%)',data:[{{CR0}},{{CR1}},{{CR2}},{{CR3}},{{CR4}},{{CR5}},{{CR6}},{{CR7}},{{CR8}},{{CR9}},{{CR10}},{{CR11}},{{CR12}}],borderColor:'#0E9F6E',backgroundColor:'rgba(14,159,110,0.1)',tension:0.3,fill:false,yAxisID:'y1'}
  ]},options:{scales:{y:{title:{display:true,text:'询盘量指数'}},y1:{type:'linear',position:'right',title:{display:true,text:'转化率(%)'},grid:{drawOnChartArea:false}}}}});`;
}

/* 使用方法：
   在 HTML 生成阶段，SKILL 会按章节选择性调用这些函数，
   把返回的 JS 代码字符串拼接到模板末尾 <script> 块中。
   所有 {{占位符}} 必须在生成时替换为真实数据，否则图表无法渲染。
*/
